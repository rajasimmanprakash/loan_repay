<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\LoanApplication;
use Validator;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;

class LoanController extends Controller
{
    public function loan_list(Request $request)
    {
		if(isset($request->user()->is_admin) && $request->user()->is_admin == 1){
			$loan_details = DB::table('users as u')
				->select('u.id as user_id','u.name','u.email','l.id as loan_id','l.loan_amount','l.loan_term','l.interest','l.status_updated_date','l.is_approved','l.installment_period','l.created_at as loan_registered_date','r.repay_status','r.repay_week_count')
				->leftJoin('loan_application as l', 'l.user_id', '=', 'u.id')
				->leftJoin('loan_repay as r', 'r.user_id', '=', 'l.user_id')
				->where('u.is_admin', '!=', 1)
				->where('l.is_approved', '!=', null)
				->orderBy('u.id', 'desc')
				->get()->toArray();
			if(isset($loan_details) && !empty($loan_details)){	
				$loan_array = array();
				foreach($loan_details as $loan){				
					if(isset($loan->is_approved) && $loan->is_approved == 1){
						$is_approved_status = 'Approved';
					}else if(isset($loan->is_approved) && $loan->is_approved == 2){
						$is_approved_status = 'Rejected';
					}else{
						$is_approved_status = 'Pending';
					}	
					$loan_arr['user_id'] 				= $loan->user_id;
					$loan_arr['name'] 					= $loan->name;
					$loan_arr['email'] 					= $loan->email;
					$loan_arr['loan_id'] 				= $loan->loan_id;
					$loan_arr['loan_amount'] 			= $loan->loan_amount;
					$loan_arr['loan_term'] 				= $loan->loan_term;
					$loan_arr['installment_period'] 	= $loan->installment_period;
					$loan_arr['loan_status'] 			= $is_approved_status;
					$loan_arr['loan_registered_date'] 	= $loan->loan_registered_date; 
					$loan_arr['interest'] 				= (isset($loan->interest) && $loan->interest != null)?$loan->interest:'';
					$loan_arr['status_updated_date'] 	= (isset($loan->status_updated_date) && $loan->status_updated_date != null)?$loan->status_updated_date:'';			
					$loan_arr['repay_week_count'] 		= (isset($loan->repay_week_count) && $loan->repay_week_count != null)?$loan->repay_week_count:0; 
					if(isset($loan->repay_status) && $loan->repay_status == 1){
						$loan_arr['loan_repay_status'] 	= 'Paid';
					}
					$loan_array[] 						= $loan_arr;
				}
				return response()->json(['status' => '200', 'loan_list' => $loan_array]);	
			}else{
				$msg = 'List not found.';
				return response()->json(['status' => '200', 'message' => $msg]);	
			}
		}else{
			return response()->json(['status' => '400', 'error' => 'Sorry! only admin having the permission to view.']);
		}
    }
	
	public function loan_approved(Request $request, $loan_id)
    {
		if(isset($request->user()->is_admin) && $request->user()->is_admin == 1){
			DB::table('loan_application')->where('id', $loan_id)->update(['is_approved' => $request->is_approved, 'interest' => $request->interest, 'status_updated_date' => date('Y-m-d h:i:s')]);
			$loan = DB::table('users as u')
				->select('u.id as user_id','u.name','u.email','l.id as loan_id','l.loan_amount','l.interest','l.status_updated_date','l.installment_period','l.loan_term','l.is_approved','l.created_at as loan_registered_date','r.repay_status','r.repay_week_count')
				->leftJoin('loan_application as l', 'l.user_id', '=', 'u.id')
				->leftJoin('loan_repay as r', 'r.user_id', '=', 'l.user_id')
				->where('l.id', '=', $loan_id)
				->first();
			if(isset($loan->repay_status) && $loan->repay_status == 1){
				$msg = "This user successfully completed to paid their loan due amount.";
				return response()->json(['status' => '200', 'message' => $msg]);
			}
			
			$validator = Validator::make($request->all(), [
			 'is_approved' 		=> 'required|integer|between:0,2',
			 'interest' 		=> 'integer|between:5,20',
			]);
			if ($validator->fails()) {
				return response()->json(['errors' => $validator->errors()]);
			}
			if(isset($request->is_approved) && ($request->is_approved == 2 || $request->is_approved == 0)){
				$loan_appint_err['interest'][] = 'The interest field is required while enter is approved 1.';
				return response()->json(['errors' => $loan_appint_err]);
			}
			if(isset($request->is_approved) && $request->is_approved == 1 && $request->interest == '' ){
				$loan_int_err['interest'][] = 'The interest field is required.';
				return response()->json(['errors' => $loan_int_err]);
			}
			if(isset($loan) && !empty($loan)){	
				if(isset($loan->is_approved) && $loan->is_approved == 1){
					$is_approved_status = 'Approved';
				}else if(isset($loan->is_approved) && $loan->is_approved == 2){
					$is_approved_status = 'Rejected';
				}else{
					$is_approved_status = 'Pending';
				}
				$loan_arr['user_id'] 				= $loan->user_id;
				$loan_arr['name'] 					= $loan->name;
				$loan_arr['email'] 					= $loan->email;
				$loan_arr['loan_id'] 				= $loan->loan_id;
				$loan_arr['loan_amount'] 			= $loan->loan_amount;
				$loan_arr['loan_term'] 				= $loan->loan_term;
				$loan_arr['installment_period'] 	= $loan->installment_period;
				$loan_arr['loan_registered_date'] 	= $loan->loan_registered_date; 
				$loan_arr['loan_status'] 			= $is_approved_status;
				$loan_arr['interest'] 				= (isset($loan->interest) && $loan->interest != null)?$loan->interest:'';
				$loan_arr['status_updated_date'] 	= (isset($loan->status_updated_date) && $loan->status_updated_date != null)?$loan->status_updated_date:'';
				$loan_arr['repay_week_count'] 		= (isset($loan->repay_week_count) && $loan->repay_week_count != null)?$loan->repay_week_count:0;
				return response()->json(['status' => '200', 'success' => 'Approved successfully.', 'user_detail' => $loan_arr]);
			}else{
				return response()->json(['status' => '400', 'error' => 'Invalid loan id.']);
			}
		}else{
			return response()->json(['status' => '400', 'error' => 'Sorry! only admin having the permission to view.']);
		}
    }
}
